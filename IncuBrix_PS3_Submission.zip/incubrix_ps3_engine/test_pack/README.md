# Test Pack

Store every request input, response, logs, output videos, timeline, manifest, SRT, and inspection notes here. Keep failed attempts.

Suggested cases:
1. 20–60 second budgeting script.
2. Product promo.
3. Tutorial.
4. Story narration.
5. Abstract line: “Trust is earned slowly.”
6. Double meanings: “value”, “bank”, “cloud”, “mouse”, “python”.
7. Named person or brand.
8. Sensitive news story.
9. Five-minute voiceover.
10. Empty script / unsupported extension / silent audio.
11. Provider disabled / provider returns no clips.
12. Two simultaneous requests.
13. 16:9 and 9:16 requested together.
14. Confirm no repeated source clips in one output.

For each case record expected result, actual result, pass/fail, evidence path, and reviewer notes. Do not remove failures.
