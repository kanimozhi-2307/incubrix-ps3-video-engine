#!/usr/bin/env python3
"""Run JSON requests from a folder against the service and save response/status snapshots."""
import argparse, json, pathlib, time, urllib.request, urllib.error
p=argparse.ArgumentParser()
p.add_argument("--base-url",default="http://localhost:8000")
p.add_argument("--input-dir",required=True)
p.add_argument("--output-dir",required=True)
a=p.parse_args()
src=pathlib.Path(a.input_dir); dst=pathlib.Path(a.output_dir); dst.mkdir(parents=True,exist_ok=True)
for f in sorted(src.glob("*.json")):
    req=json.loads(f.read_text())
    key=req.pop("_idempotency_key",f.stem)
    data=json.dumps(req).encode()
    r=urllib.request.Request(a.base_url+"/api/v1/broll/jobs",data=data,headers={"Content-Type":"application/json","Idempotency-Key":key},method="POST")
    try:
        with urllib.request.urlopen(r,timeout=30) as resp: result=json.loads(resp.read())
    except urllib.error.HTTPError as e: result={"http_status":e.code,"body":e.read().decode(errors="replace")}
    if "job_id" in result:
        for _ in range(360):
            time.sleep(1)
            try:
                with urllib.request.urlopen(a.base_url+result["status_url"],timeout=10) as resp: status=json.loads(resp.read())
            except Exception as e: status={"poll_error":str(e)}
            if status.get("status") in ("succeeded","failed"): break
        result["final_status"]=status
    (dst/(f.stem+"_result.json")).write_text(json.dumps(result,indent=2))
    print(f"{f.name}: {result.get('final_status',result).get('status','request_error') if isinstance(result.get('final_status',result),dict) else 'done'}")
